<?php
session_start();
include('config/conex.php');

// Verificar si la sesión está iniciada
if (isset($_SESSION['user_id'])) {
    // Restablecer el estado del usuario a 0
    $stmt = $dbh->prepare("UPDATE usuarios SET estado = 0 WHERE id = :id");
    $stmt->bindParam(':id', $_SESSION['user_id']);
    $stmt->execute();

    // Eliminar variable de animación de bienvenida
    unset($_SESSION['bienvenida_mostrada']);

    
    session_unset();
    session_destroy();

    header('Location: index.html'); // Redirigir a la página de login
    exit();
}
?>
