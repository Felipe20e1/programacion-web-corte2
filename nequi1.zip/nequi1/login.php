<?php
include('config/conex.php');
session_start();  // Iniciar la sesión para manejar la autenticación

$mensaje = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $numero_telefono = $_POST['numero_telefono'];
    $contraseña = $_POST['contraseña'];

    // Verificar si el número de teléfono existe en la base de datos
    $stmt = $dbh->prepare("SELECT * FROM usuarios WHERE numero_telefono = :numero_telefono");
    $stmt->bindParam(':numero_telefono', $numero_telefono);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && $user['contraseña'] === $contraseña) {
        // Iniciar sesión (guardar datos en la sesión)
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['nombre'] = $user['nombre'];

        // Actualizar el estado del usuario a 1 (logueado)
        $stmt = $dbh->prepare("UPDATE usuarios SET estado = 1 WHERE id = :id");
        $stmt->bindParam(':id', $user['id']);
        $stmt->execute();

        // Redirigir a la página de menú
        header('Location: menu.php');
        exit();
    } else {
        $mensaje = "❌ Número de teléfono o contraseña incorrectos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión Nequi</title>
    <style>
        :root {
            --color-principal: #ff0080;
            --color-fondo: #fff;
            --color-texto: #2e003e;
            --color-campo: #fde6f1;
        }

        body {
            background-color: var(--color-fondo);
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .formulario {
            width: 90%;
            max-width: 400px;
            background-color: var(--color-fondo);
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 0 20px rgba(255, 0, 130, 0.2);
        }

        .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .logo img {
            max-width: 120px;
        }

        h1 {
            color: var(--color-texto);
            text-align: center;
            margin-bottom: 20px;
        }

        .campo {
            background-color: var(--color-campo);
            border-radius: 12px;
            margin-bottom: 18px;
            padding: 18px 12px 10px 44px;
            position: relative;
            transition: 0.3s ease;
        }

        .campo input {
            width: 100%;
            border: none;
            background: transparent;
            font-size: 16px;
            color: var(--color-texto);
            outline: none;
            margin-top: 5px;
        }

        .campo label {
            position: absolute;
            top: 14px;
            left: 44px;
            font-size: 12px;
            color: var(--color-principal);
            font-weight: 600;
            transition: 0.3s ease;
        }

        .campo input:focus + label,
        .campo input:not(:placeholder-shown) + label {
            top: 5px;
            font-size: 11px;
            color: var(--color-principal);
        }

        .campo:focus-within {
            box-shadow: 0 0 0 2px var(--color-principal);
        }

        .icono {
            position: absolute;
            top: 16px;
            left: 14px;
            width: 20px;
            height: 20px;
        }

        button {
            width: 100%;
            padding: 14px;
            background-color: var(--color-principal);
            color: white;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            transition: 0.3s ease;
        }

        button:hover {
            background-color: #e60073;
        }

        .formulario a {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: var(--color-texto);
            text-decoration: none;
            font-weight: 500;
        }

        .formulario a:hover {
            text-decoration: underline;
        }

        .mensaje {
            margin-top: 15px;
            text-align: center;
            color: #ffd700;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <div class="formulario">
        <div class="logo">
            <img src="assets/logo-nequi.png" alt="Logo Nequi">
        </div>

        <h1>Iniciar Sesión Nequi</h1>
        <form method="POST" action="login.php">
            <div class="campo">
                <img class="icono" src="assets/icons/phone.png" alt="icono teléfono">
                <input type="text" id="numero_telefono" name="numero_telefono" placeholder="" required>
                <label for="numero_telefono">Número de teléfono</label>
            </div>

            <div class="campo">
                <img class="icono" src="assets/icons/password.png" alt="icono contraseña">
                <input type="password" id="contraseña" name="contraseña" placeholder="" required>
                <label for="contraseña">Contraseña</label>
            </div>

            <button type="submit">Iniciar sesión</button>
        </form>

        <?php if (!empty($mensaje)): ?>
            <div class="mensaje"><?php echo $mensaje; ?></div>
        <?php endif; ?>

        <a href="registro.html">¿No tienes cuenta? Regístrate aquí</a>
    </div>

</body>
</html>
