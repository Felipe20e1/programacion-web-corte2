<?php 
session_start();
include('config/conex.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $monto = $_POST['monto'];

    if ($monto <= 0) {
        echo "El monto debe ser mayor que 0.";
    } else {
        $query = "SELECT saldo FROM usuarios WHERE id = :user_id";
        $stmt = $dbh->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user['saldo'] < $monto) {
            echo "No tienes suficiente saldo.";
        } else {
            try {
                $dbh->beginTransaction();

                $stmt = $dbh->prepare("UPDATE usuarios SET saldo = saldo - :monto WHERE id = :user_id");
                $stmt->bindParam(':monto', $monto);
                $stmt->bindParam(':user_id', $user_id);
                $stmt->execute();

                $stmt = $dbh->query("
                    SELECT MIN(t1.id + 1) AS id_libre
                    FROM historial_movimientos t1
                    LEFT JOIN historial_movimientos t2 ON t1.id + 1 = t2.id
                    WHERE t2.id IS NULL
                ");
                $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
                $id_libre = $resultado['id_libre'];

                if (!$id_libre) {
                    $stmt = $dbh->query("SELECT IFNULL(MAX(id), 0) + 1 AS id_libre FROM historial_movimientos");
                    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
                    $id_libre = $resultado['id_libre'];
                }

                $stmt = $dbh->prepare("INSERT INTO historial_movimientos 
                    (id, user_id, tipo_operacion, monto, destinatario_id, fecha_hora) 
                    VALUES (:id, :user_id, 'Retiro', :monto, :destinatario_id, NOW())");

                $stmt->bindParam(':id', $id_libre);
                $stmt->bindParam(':user_id', $user_id);
                $stmt->bindParam(':monto', $monto);
                $stmt->bindParam(':destinatario_id', $user_id);
                $stmt->execute();

                $dbh->commit();

                echo $user['saldo'] - $monto;
            } catch (Exception $e) {
                $dbh->rollBack();
                echo "Error al procesar el retiro.";
            }
        }
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Retirar Dinero</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f2f2f2;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 60px;
        }

        .container {
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            width: 90%;
            max-width: 400px;
            text-align: center;
        }

        h1 {
            color: #8b2be2;
            margin-bottom: 20px;
        }

        input[type="number"] {
            width: 100%;
            padding: 12px;
            border-radius: 10px;
            border: 1px solid #ccc;
            margin-bottom: 20px;
            font-size: 16px;
        }

        button {
            background-color: #8b2be2;
            color: white;
            padding: 12px 25px;
            font-size: 16px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #6e22b5;
        }

        #saldo {
            margin-top: 20px;
            font-weight: bold;
            color: #333;
        }

        .btn-regresar {
            background-color: #e0e0e0;
            color: #333;
            margin-top: 15px;
        }

        .btn-regresar:hover {
            background-color: #d0d0d0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Retirar Dinero</h1>
        <form id="formRetiro">
            <input type="number" id="monto" name="monto" placeholder="Ingresa el monto" required>
            <button type="submit">Retirar</button>
        </form>

        <div id="saldo"></div>

        <button class="btn-regresar" onclick="window.location.href='menu.php'">Regresar</button>
    </div>

    <script>
        $(document).ready(function() {
            $("#formRetiro").submit(function(e) {
                e.preventDefault();
                var monto = $("#monto").val();

                $.ajax({
                    type: "POST",
                    url: "retirar.php",
                    data: { monto: monto },
                    success: function(response) {
                        if (isNaN(response)) {
                            alert(response);
                        } else {
                            $("#saldo").text("Saldo disponible: " + response);
                            alert("Retiro realizado con éxito.");
                        }
                    },
                    error: function() {
                        alert("Hubo un error en el retiro.");
                    }
                });
            });
        });
    </script>
</body>
</html>
