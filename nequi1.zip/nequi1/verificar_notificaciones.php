<?php
session_start();
include('config/conex.php');

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['total' => 0]);
    exit();
}

$user_id = $_SESSION['user_id'];

// Contar transferencias recibidas no vistas
$stmt = $dbh->prepare("SELECT COUNT(*) AS total FROM historial_movimientos 
    WHERE user_id = :id 
    AND tipo_operacion = 'Transferencia Recibida' 
    AND vista_por_destinatario = 0");
$stmt->bindParam(':id', $user_id);
$stmt->execute();
$resultado = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode(['total' => intval($resultado['total'])]);
exit();
