<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Mostrar animación solo la primera vez que se entra al menú después del login
if (!isset($_SESSION['bienvenida_mostrada'])) {
    $_SESSION['bienvenida_mostrada'] = true;
    $mostrarLoader = true;
} else {
    $mostrarLoader = false;
}

$user_id = $_SESSION['user_id'];

include('config/conex.php');
$stmt = $dbh->prepare("SELECT saldo, nombre FROM usuarios WHERE id = :user_id");
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Consulta para contar las notificaciones no vistas de transferencias recibidas
$stmt_notifications = $dbh->prepare("SELECT COUNT(*) AS notificaciones_no_vistas 
  FROM historial_movimientos 
  WHERE user_id = :user_id 
  AND tipo_operacion = 'Transferencia Recibida' 
  AND vista_por_destinatario = 0");

$stmt_notifications->bindParam(':user_id', $user_id);
$stmt_notifications->execute();
$notifications = $stmt_notifications->fetch(PDO::FETCH_ASSOC);
$notificaciones_no_vistas = $notifications['notificaciones_no_vistas'];

// Verificamos si el mensaje de notificación ya se mostró
if ($notificaciones_no_vistas > 0 && !isset($_SESSION['notificaciones_mostradas'])) {
    $_SESSION['notificaciones_mostradas'] = true;
    $mostrarMensajeNotificacion = true;
} else {
    $mostrarMensajeNotificacion = false;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Principal</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to bottom right, #6f2c91, #d6006d);
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        .loader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #6f2c91;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            visibility: visible;
            opacity: 1;
            transition: opacity 1s ease, visibility 1s ease;
        }

        .loader img {
            width: 120px;
            height: 120px;
        }

        header {
            width: 100%;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
        }

        .saldo {
            margin-top: 10px;
            font-size: 18px;
        }

        .menu {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 20px;
            padding: 30px;
            width: 90%;
            max-width: 600px;
        }

        .menu-item {
            background-color: white;
            color: #333;
            border-radius: 15px;
            text-align: center;
            padding: 15px;
            text-decoration: none;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.2s;
            position: relative; /* Importante para la posición de las notificaciones */
        }

        .menu-item:hover {
            transform: translateY(-5px);
        }

        .menu-item img {
            width: 50px;
            height: 50px;
            margin-bottom: 10px;
        }

        .menu-item span {
            display: block;
            font-weight: bold;
        }

        .menu-item .notificaciones {
            background-color: red;
            color: white;
            padding: 2px 5px;
            border-radius: 50%;
            font-size: 12px;
            position: absolute;
            top: 5px;
            right: 5px;
        }

        .mensaje-notificacion {
            background-color: #ff6f61;
            padding: 15px;
            margin: 15px 0;
            border-radius: 8px;
            text-align: center;
            font-weight: bold;
        }

        @media (max-width: 480px) {
            header h1 {
                font-size: 20px;
            }

            header p, .saldo {
                font-size: 14px;
            }

            .menu {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
                padding: 20px;
            }

            .menu-item {
                padding: 10px;
            }

            .menu-item img {
                width: 40px;
                height: 40px;
            }

            .menu-item span {
                font-size: 13px;
            }
        }
    </style>
    <script>
        window.addEventListener("load", function () {
            const loader = document.getElementById("loader");
            if (loader) {
                setTimeout(() => {
                    loader.style.opacity = 0;
                    loader.style.visibility = "hidden";
                }, 3500);
            }
        });
    </script>
</head>
<body>
    <?php if ($mostrarLoader): ?>
    <div class="loader" id="loader">
        <img src="assets/icons/logo-girando.gif" alt="Cargando...">
    </div>
    <?php endif; ?>

    <header>
        <h1>Hola, <?php echo htmlspecialchars($user['nombre']); ?></h1>
        <p>Bienvenido al menú de Nequi</p>
        <p>Selecciona una opción para manejar tu dinero</p>
        <div class="saldo">Saldo disponible: $<?php echo number_format($user['saldo'], 2); ?></div>
    </header>

    <?php if ($mostrarMensajeNotificacion): ?>
        <div class="mensaje-notificacion">
            Tienes notificaciones nuevas que aún no has visto. ¡No olvides revisar tus movimientos!
        </div>
    <?php endif; ?>

    <div class="menu">
        <a class="menu-item" href="ver_movimientos.php">
            <img src="assets/icons/movimientos.png" alt="Movimientos">
            <span>Movimientos</span>
            <?php if ($notificaciones_no_vistas > 0): ?>
                <span class="notificaciones"><?php echo $notificaciones_no_vistas; ?></span>
            <?php endif; ?>
        </a>
        <a class="menu-item" href="transferir.php">
            <img src="assets/icons/transferir.png" alt="Transferir">
            <span>Transferir</span>
        </a>
        <a class="menu-item" href="retirar.php">
            <img src="assets/icons/retirar.png" alt="Retirar">
            <span>Retirar</span>
        </a>
        <a class="menu-item" href="consignar.php">
            <img src="assets/icons/consignar.png" alt="Consignar">
            <span>Consignar</span>
        </a>
        <a class="menu-item" href="logout.php">
            <img src="assets/icons/salir.png" alt="Salir">
            <span>Salir</span>
        </a>
    </div>
</body>
</html>
