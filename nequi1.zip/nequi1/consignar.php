<?php
include('config/conex.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Solo responde si es petición AJAX
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ajax'])) {
    $monto_consignar = $_POST['monto_consignar'];
    $user_id = $_SESSION['user_id'];

    if ($monto_consignar <= 0) {
        echo "El monto debe ser mayor que 0.";
    } else {
        // Verificar saldo actual del usuario
        $stmt = $dbh->prepare("SELECT saldo FROM usuarios WHERE id = :id");
        $stmt->bindParam(':id', $user_id);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Calcular el nuevo saldo
            $nuevo_saldo = $user['saldo'] + $monto_consignar;

            // Actualizar el saldo del usuario
            $stmt = $dbh->prepare("UPDATE usuarios SET saldo = :saldo WHERE id = :id");
            $stmt->bindParam(':saldo', $nuevo_saldo);
            $stmt->bindParam(':id', $user_id);
            $stmt->execute();

            // Buscar el primer ID disponible (hueco) en la tabla historial_movimientos
            $stmt = $dbh->query("
                SELECT MIN(t1.id + 1) AS id_libre
                FROM historial_movimientos t1
                LEFT JOIN historial_movimientos t2 ON t1.id + 1 = t2.id
                WHERE t2.id IS NULL
            ");
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            $id_libre = $resultado['id_libre'];

            // Si no hay huecos, buscar el siguiente id máximo
            if (!$id_libre) {
                $stmt = $dbh->query("SELECT IFNULL(MAX(id), 0) + 1 AS id_libre FROM historial_movimientos");
                $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
                $id_libre = $resultado['id_libre'];
            }

            // Insertar en el historial con ID específico
            $stmt = $dbh->prepare("INSERT INTO historial_movimientos (id, user_id, tipo_operacion, monto, destinatario_id, fecha_hora) 
                                   VALUES (:id, :user_id, 'Consignación', :monto, :destinatario_id, NOW())");
            $stmt->bindParam(':id', $id_libre);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':monto', $monto_consignar);
            $stmt->bindParam(':destinatario_id', $user_id);
            $stmt->execute();

            echo "ok|$nuevo_saldo";
        } else {
            echo "error|Usuario no encontrado.";
        }
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consignar Dinero</title>
    <style>
        body {
            background-color: #f3f3f3;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 400px;
            margin: 60px auto;
            background-color: white;
            border-radius: 15px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
            padding: 30px;
        }
        h1 {
            text-align: center;
            color: #8b006d;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }
        input[type="number"] {
            width: 100%;
            padding: 12px;
            border-radius: 10px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-size: 16px;
            margin-bottom: 20px;
        }
        button {
            width: 100%;
            padding: 12px;
            background-color: #8b006d;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #a0007a;
        }
        #mensaje {
            text-align: center;
            margin-top: 15px;
            font-weight: bold;
            color: green;
        }
        .volver {
            margin-top: 20px;
            text-align: center;
        }
        .volver button {
            background-color: #333;
        }
    </style>
    <script>
        function consignarDinero(event) {
            event.preventDefault();
            const monto = document.getElementById('monto_consignar').value;

            // Validación del monto antes de enviar
            if (monto <= 0) {
                document.getElementById('mensaje').innerText = '⚠️ El monto debe ser mayor que 0.';
                document.getElementById('mensaje').style.color = 'red';
                return;
            }

            fetch('consignar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `monto_consignar=${monto}&ajax=1`
            })
            .then(response => response.text())
            .then(data => {
                const partes = data.split('|');
                if (partes[0] === 'ok') {
                    document.getElementById('mensaje').innerText = `✅ Consignación exitosa. Nuevo saldo: ${partes[1]}`;
                } else {
                    document.getElementById('mensaje').innerText = `⚠️ ${partes[1]}`;
                    document.getElementById('mensaje').style.color = 'red';
                }
            })
            .catch(error => {
                document.getElementById('mensaje').innerText = '⚠️ Error al procesar la solicitud.';
                document.getElementById('mensaje').style.color = 'red';
            });
        }
    </script>
</head>
<body>
    <div class="container">
        <h1>Consignar</h1>
        <form onsubmit="consignarDinero(event)">
            <label for="monto_consignar">Monto a consignar</label>
            <input type="number" id="monto_consignar" name="monto_consignar" required>
            <button type="submit">Confirmar Consignación</button>
        </form>
        <p id="mensaje"></p>
        <div class="volver">
            <button onclick="window.location.href='menu.php'">Regresar al Menú</button>
        </div>
    </div>
</body>
</html>
