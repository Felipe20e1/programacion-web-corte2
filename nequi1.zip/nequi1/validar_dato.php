<?php
include("config/conex.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validar los datos recibidos
    $campo = isset($_POST["campo"]) ? $_POST["campo"] : '';
    $valor = isset($_POST["valor"]) ? $_POST["valor"] : '';

    // Verificar que los campos no estén vacíos
    if (empty($campo) || empty($valor)) {
        echo json_encode(["valido" => false, "error" => "Datos incompletos."]);
        exit;
    }

    // Inicializar la variable de consulta
    $validar = "";

    // Determinar la consulta según el campo a validar
    if ($campo == "correo") {
        $validar = "SELECT * FROM usuarios WHERE correo = ?";
    } elseif ($campo == "numero_telefono") {
        $validar = "SELECT * FROM usuarios WHERE numero_telefono = ?";
    } elseif ($campo == "numero_identificacion") {
        $validar = "SELECT * FROM usuarios WHERE numero_identificacion = ?";
    } else {
        echo json_encode(["valido" => false, "error" => "Campo desconocido."]);
        exit;
    }

    try {
        // Preparar la consulta
        $stmt = $dbh->prepare($validar);
        $stmt->execute([$valor]);

        // Verificar si existe un registro con ese valor
        if ($stmt->rowCount() > 0) {
            echo json_encode(["valido" => false, "error" => "Este $campo ya está registrado."]);
        } else {
            echo json_encode(["valido" => true]);
        }
    } catch (Exception $e) {
        // En caso de error, enviar un mensaje de error
        echo json_encode(["valido" => false, "error" => "Error al validar el dato: " . $e->getMessage()]);
    }
}
?>
