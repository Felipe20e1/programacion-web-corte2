<?php
include("config/conex.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $contraseña = $_POST["contraseña"];
    $confirmar = $_POST["confirmar_contraseña"];
    $numero_identificacion = $_POST["numero_identificacion"];
    $numero_telefono = $_POST["numero_telefono"];
    $tipo_de_identificacion = $_POST["tipo_de_identificacion"];

    $errores = [];

    // Validar que las contraseñas coincidan
    if ($contraseña !== $confirmar) {
        $errores[] = 'contraseña';
    }

    // Validar correo
    $verificarCorreo = $dbh->prepare("SELECT id FROM usuarios WHERE correo = ?");
    $verificarCorreo->execute([$correo]);
    if ($verificarCorreo->rowCount() > 0) {
        $errores[] = 'correo';
    }

    // Validar número de teléfono
    $verificarTelefono = $dbh->prepare("SELECT id FROM usuarios WHERE numero_telefono = ?");
    $verificarTelefono->execute([$numero_telefono]);
    if ($verificarTelefono->rowCount() > 0) {
        $errores[] = 'telefono';
    }

    // Validar número de identificación
    $verificarDocumento = $dbh->prepare("SELECT id FROM usuarios WHERE numero_identificacion = ?");
    $verificarDocumento->execute([$numero_identificacion]);
    if ($verificarDocumento->rowCount() > 0) {
        $errores[] = 'documento';
    }

    // Si hay errores, redirigir
    if (!empty($errores)) {
        $error_str = implode(',', $errores);
        header("Location: registro.html?error=$error_str");
        exit();
    }

    // No encriptamos la contraseña por indicación tuya
    $contraseña_original = $contraseña;

    // Buscar el primer ID disponible
    $ids = $dbh->query("SELECT id FROM usuarios ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);
    $nextAvailableId = null;

    for ($i = 1; $i <= count($ids) + 1; $i++) {
        if (!in_array($i, $ids)) {
            $nextAvailableId = $i;
            break;
        }
    }

    // Armar SQL con o sin ID
    if (!$nextAvailableId) {
        $sql = "INSERT INTO usuarios 
                (nombre, tipo_de_identificacion, correo, `contraseña`, numero_identificacion, numero_telefono, saldo, estado, created_at)
                VALUES 
                ('$nombre', '$tipo_de_identificacion', '$correo', '$contraseña_original', '$numero_identificacion', '$numero_telefono', 0, 0, NOW())";
    } else {
        $sql = "INSERT INTO usuarios 
                (id, nombre, tipo_de_identificacion, correo, `contraseña`, numero_identificacion, numero_telefono, saldo, estado, created_at)
                VALUES 
                ('$nextAvailableId', '$nombre', '$tipo_de_identificacion', '$correo', '$contraseña_original', '$numero_identificacion', '$numero_telefono', 0, 0, NOW())";
    }

    // Ejecutar
    if ($dbh->query($sql)) {
        header("Location: login.php");
        exit();
    } else {
        echo "Error al crear la cuenta.";
    }
}
?>
