<?php
session_start();
include('config/conex.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $monto = floatval($_POST['monto']);
    $destino = $_POST['destinatario'];
    $user_id = $_SESSION['user_id'];

    if ($monto <= 0) {
        echo "El monto debe ser mayor que 0.";
        exit();
    }

    $stmt = $dbh->prepare("SELECT saldo, nombre, numero_telefono FROM usuarios WHERE id = :id");
    $stmt->bindParam(':id', $user_id);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user['saldo'] < $monto) {
        echo "No tienes suficiente saldo.";
        exit();
    }

    $stmt = $dbh->prepare("SELECT id, nombre, numero_telefono FROM usuarios WHERE numero_telefono = :telefono");
    $stmt->bindParam(':telefono', $destino);
    $stmt->execute();
    if ($stmt->rowCount() === 0) {
        echo "El destinatario no existe.";
        exit();
    }

    $dest = $stmt->fetch(PDO::FETCH_ASSOC);
    $dest_id = $dest['id'];
    $dest_nombre = $dest['nombre'];
    $dest_numero_telefono = $dest['numero_telefono'];

    try {
        $dbh->beginTransaction();

        $stmt = $dbh->prepare("UPDATE usuarios SET saldo = saldo - :monto WHERE id = :id");
        $stmt->bindParam(':monto', $monto);
        $stmt->bindParam(':id', $user_id);
        $stmt->execute();

        $stmt = $dbh->prepare("UPDATE usuarios SET saldo = saldo + :monto WHERE id = :id");
        $stmt->bindParam(':monto', $monto);
        $stmt->bindParam(':id', $dest_id);
        $stmt->execute();

        $stmt = $dbh->query("SELECT MIN(t1.id + 1) AS id_libre
                              FROM historial_movimientos t1
                              LEFT JOIN historial_movimientos t2 ON t1.id + 1 = t2.id
                              WHERE t2.id IS NULL");
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        $id_libre = $resultado['id_libre'] ?: $dbh->query("SELECT IFNULL(MAX(id), 0) + 1 AS id_libre FROM historial_movimientos")->fetch(PDO::FETCH_ASSOC)['id_libre'];

        $stmt = $dbh->prepare("INSERT INTO historial_movimientos 
            (id, user_id, tipo_operacion, monto, destinatario_id, destinatario_nombre, destinatario_numero, fecha_hora) 
            VALUES (:id, :user_id, 'Transferencia', :monto, :destinatario_id, :destinatario_nombre, :destinatario_numero, NOW())");
        $stmt->execute([
            ':id' => $id_libre,
            ':user_id' => $user_id,
            ':monto' => $monto,
            ':destinatario_id' => $dest_id,
            ':destinatario_nombre' => $dest_nombre,
            ':destinatario_numero' => $dest_numero_telefono
        ]);

        $id_libre++;
        $stmt = $dbh->prepare("INSERT INTO historial_movimientos 
            (id, user_id, tipo_operacion, monto, usuarioqenvia_nombre, numeroqenvia_numero, fecha_hora, vista_por_destinatario) 
            VALUES (:id, :user_id, 'Transferencia Recibida', :monto, :usuarioqenvia_nombre, :numeroqenvia_numero, NOW(), 0)");
        $stmt->execute([
            ':id' => $id_libre,
            ':user_id' => $dest_id,
            ':monto' => $monto,
            ':usuarioqenvia_nombre' => $user['nombre'],
            ':numeroqenvia_numero' => $user['numero_telefono']
        ]);

        $dbh->commit();
        echo "Has transferido $monto a $dest_nombre (número $destino).";
    } catch (Exception $e) {
        $dbh->rollBack();
        echo "Error en la transferencia.";
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Transferir Dinero</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(to bottom right, #a400ff, #ff0080);
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 30px;
        }

        h1 {
            margin-bottom: 20px;
            font-size: 28px;
        }

        form {
            background-color: white;
            color: #333;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            border-radius: 10px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        button {
            width: 100%;
            background-color: #a400ff;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 10px;
            margin-top: 20px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #8700cc;
        }

        #resultado {
            margin-top: 20px;
            font-weight: bold;
            text-align: center;
        }

        .volver {
            margin-top: 25px;
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .volver:hover {
            text-decoration: underline;
        }
    </style>
    <script>
        function transferir(event) {
            event.preventDefault();
            const monto = document.getElementById("monto").value;
            const destinatario = document.getElementById("destinatario").value;

            fetch('transferir.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'monto=' + monto + '&destinatario=' + destinatario
            })
            .then(response => response.text())
            .then(data => {
                document.getElementById("resultado").innerText = data;
            });
        }
    </script>
</head>
<body>
    <h1>Transferencia</h1>
    <form onsubmit="transferir(event)">
        <label>Número del destinatario</label>
        <input type="text" id="destinatario" name="destinatario" required>

        <label>Monto a transferir</label>
        <input type="number" id="monto" name="monto" required min="1" step="0.01">

        <button type="submit">Enviar dinero</button>
        <div id="resultado"></div>
    </form>
    <a class="volver" href="menu.php">← Volver al menú</a>
</body>
</html>
