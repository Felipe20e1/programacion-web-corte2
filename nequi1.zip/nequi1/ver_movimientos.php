<?php
session_start();
include('config/conex.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Marcar como vistas solo las transferencias recibidas no vistas
$stmt_update = $dbh->prepare("UPDATE historial_movimientos 
    SET vista_por_destinatario = 1 
    WHERE user_id = :user_id 
    AND tipo_operacion = 'Transferencia Recibida' 
    AND vista_por_destinatario = 0");
$stmt_update->bindParam(':user_id', $user_id);
$stmt_update->execute();

// Obtener todos los movimientos del usuario
$stmt = $dbh->prepare("
    SELECT tipo_operacion, monto, fecha_hora, 
           destinatario_nombre, destinatario_numero, 
           usuarioqenvia_nombre, numeroqenvia_numero 
    FROM historial_movimientos 
    WHERE user_id = :user_id 
    ORDER BY fecha_hora DESC
");
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
$movimientos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Movimientos</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f3f4f6;
            margin: 0;
            padding: 20px;
            color: #333;
        }

        h1 {
            text-align: center;
            color: #6c1d45;
        }

        .container {
            max-width: 900px;
            margin: auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            overflow-x: auto;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            text-align: center;
            padding: 12px 10px;
        }

        thead {
            background-color: #6c1d45;
            color: white;
        }

        tbody tr:nth-child(odd) {
            background-color: #f9f9f9;
        }

        tbody tr:nth-child(even) {
            background-color: #fff;
        }

        button {
            background-color: #6c1d45;
            color: white;
            padding: 10px 25px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            display: block;
            margin: 20px auto 0 auto;
            font-size: 16px;
        }

        button:hover {
            background-color: #5a183a;
        }

        @media (max-width: 600px) {
            th, td {
                font-size: 14px;
                padding: 8px;
            }

            h1 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Historial de Movimientos</h1>

        <table>
            <thead>
                <tr>
                    <th>Tipo de operación</th>
                    <th>Monto</th>
                    <th>Fecha y hora</th>
                    <th>Nombre relacionado</th>
                    <th>Número relacionado</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($movimientos as $movimiento): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($movimiento['tipo_operacion'] ?? 'No especificado'); ?></td>
                        <td>$<?php echo number_format($movimiento['monto'], 2); ?></td>
                        <td><?php echo $movimiento['fecha_hora']; ?></td>

                        <?php
                        $tipo_operacion = strtolower($movimiento['tipo_operacion'] ?? '');

                        if ($tipo_operacion === 'transferencia') {
                            echo "<td>" . htmlspecialchars($movimiento['destinatario_nombre'] ?? 'No especificado') . "</td>";
                            echo "<td>" . htmlspecialchars($movimiento['destinatario_numero'] ?? 'No especificado') . "</td>";
                        } elseif ($tipo_operacion === 'transferencia recibida') {
                            echo "<td>" . htmlspecialchars($movimiento['usuarioqenvia_nombre'] ?? 'No especificado') . "</td>";
                            echo "<td>" . htmlspecialchars($movimiento['numeroqenvia_numero'] ?? 'No especificado') . "</td>";
                        } else {
                            $stmt2 = $dbh->prepare("SELECT nombre, numero_telefono FROM usuarios WHERE id = :id");
                            $stmt2->bindParam(':id', $user_id);
                            $stmt2->execute();
                            $usuario = $stmt2->fetch(PDO::FETCH_ASSOC);

                            echo "<td>" . htmlspecialchars($usuario['nombre'] ?? 'No especificado') . "</td>";
                            echo "<td>" . htmlspecialchars($usuario['numero_telefono'] ?? 'No especificado') . "</td>";
                        }
                        ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <button onclick="window.location.href='menu.php'">Regresar</button>
    </div>
</body>
</html>
