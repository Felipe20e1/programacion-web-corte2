<?php
require 'config/conex.php';

$codigo = $_POST['codigo'];
$aplica_descuento = $_POST['aplica_descuento'];


$sql = "SELECT cantidad, valor FROM ventas_colibron_armenta WHERE id = ?";
$stmt = $dbh->prepare($sql);
$stmt->execute([$codigo]);
$venta = $stmt->fetch(PDO::FETCH_ASSOC);

if ($venta) {
    $cantidad = $venta['cantidad'];
    $valor = $venta['valor'];
    $total = $cantidad * $valor;

    if ($aplica_descuento == 'si') {
        $total = $total - ($total * 0.05); 
    }

   
    $sql = "UPDATE ventas_colibron_armenta SET aplica_descuento = ?, total = ? WHERE id = ?";
    $stmt = $dbh->prepare($sql);
    $stmt->execute([$aplica_descuento, $total, $codigo]);

    echo "Se editó satisfactoriamente.";
} else {
    echo "Venta no encontrada.";
}
?>
