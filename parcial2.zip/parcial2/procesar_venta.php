<?php
require 'config/conex.php';  

$tipo_de_bebida = $_POST['tipo_de_bebida'];
$cantidad = $_POST['cantidad'];
$es_madre = $_POST['es_madre'];

if ($cantidad <= 0) {
    echo "La cantidad debe ser mayor a 0.";
    exit;
}

if ($tipo_de_bebida == 'gaseosa') {
    $precio_unitario = 6000;
} elseif ($tipo_de_bebida == 'cerveza') {
    $precio_unitario = 8000;
} elseif ($tipo_de_bebida == 'aguardiente') {
    $precio_unitario = 10000;
} else {
    echo "Debe seleccionar un tipo de bebida válido.";
    exit;
}

$total = $precio_unitario * $cantidad;

if ($es_madre == 'si') {
    $total -= $total * 0.05;  
}

$sql = "INSERT INTO ventas_colibron_armenta (cantidad, tipo_de_bebida, valor, total, aplica_descuento) VALUES (?, ?, ?, ?, ?)";
$stmt = $dbh->prepare($sql);
$stmt->execute([$cantidad, $tipo_de_bebida, $precio_unitario, $total, $es_madre]);
echo "<h2>Venta realizada correctamente</h2>";
echo "<a href='index.html'>Volver al inicio</a>";
?>
