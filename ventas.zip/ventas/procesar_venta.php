<?php
require 'config/conex.php';  

$valor = $_POST['valor'];
$cantidad = $_POST['cantidad'];


if ($valor <= 0) {
    echo "No se pueden ingresar valores o cantidades menores o iguales a 0.";
    exit;
}
if ( $cantidad <= 0) {
    echo "No se pueden ingresar valores o cantidades menores o iguales a 0.";
    exit;
}

$total = $valor * $cantidad;

$sql = "INSERT INTO ventas (cantidad, valor, total) VALUES (?, ?, ?)";
$stmt = $dbh->prepare($sql);  
$stmt->execute([$cantidad, $valor, $total]);

header("Location: index.html?venta=realizada");
exit;
?>

