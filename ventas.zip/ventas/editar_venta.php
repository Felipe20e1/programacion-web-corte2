<?php
require 'config/conex.php';

$id = $_POST['id'];
$nueva_cantidad = $_POST['nueva_cantidad'];
$nuevo_valor = $_POST['nuevo_valor'];
if ($nuevo_valor <= 0) {
    echo "No se pueden ingresar valores o cantidades menores o iguales a 0.";
    exit;
}
if ( $nueva_cantidad <= 0) {
    echo "No se pueden ingresar valores o cantidades menores o iguales a 0.";
    exit;
}
$nuevo_total = $nueva_cantidad * $nuevo_valor;

$sql = "UPDATE ventas SET cantidad = ?, valor = ?, total = ? WHERE id = ?";
$stmt = $dbh->prepare($sql);
$stmt->execute([$nueva_cantidad, $nuevo_valor, $nuevo_total, $id]);

header("Location: index.html");
exit;
?>
