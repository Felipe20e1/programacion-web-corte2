<?php

$nombre = $_POST['nombre'];
$estrato = $_POST['estrato'];
$cantidad = $_POST['txt_cantidad'];



    


$costo_almuerzo = 1500;


if ($estrato < 3) {  
    if ($cantidad > 1) {
        $total_pagar = ($cantidad - 1) * $costo_almuerzo; 
    } else {
        $total_pagar = 0;       
    }
} else {    
 $total_pagar = $cantidad * $costo_almuerzo;  
}


echo "<h2>Señor $nombre  usted debe pagar: $total_pagar pesos</h2>";
?>
