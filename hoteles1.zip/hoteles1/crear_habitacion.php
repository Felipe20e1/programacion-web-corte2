<?php

// Paso 1: importar la conexión
require 'config/conex.php';

// Paso 2: capturar el nombre de la habitación (suite o general)
$nombre = $_POST['nombre'];

// Paso 3: buscar el primer id disponible
$sqlBuscarIdDisponible = "SELECT id + 1 AS siguiente_id FROM habitaciones_armenta 
                          WHERE id + 1 NOT IN (SELECT id FROM habitaciones_armenta) 
                          LIMIT 1";
$result = $dbh->query($sqlBuscarIdDisponible);

// Si encontramos un id disponible, lo usamos
if ($result && $row = $result->fetch(PDO::FETCH_ASSOC)) {
    $nuevoId = $row['siguiente_id'];
} else {
    // Si no hay un id disponible, tomamos el siguiente id autoincremental
    $sqlUltimaHabitacion = "SELECT MAX(id) AS max_id FROM habitaciones_armenta";
    $result = $dbh->query($sqlUltimaHabitacion);
    $row = $result->fetch(PDO::FETCH_ASSOC);
    $nuevoId = $row['max_id'] + 1;
}

// Paso 4: obtener el último piso y número registrados
$sqlUltimaHabitacion = "SELECT piso, numero FROM habitaciones_armenta ORDER BY id DESC LIMIT 1";
$result = $dbh->query($sqlUltimaHabitacion);

if ($result && $row = $result->fetch(PDO::FETCH_ASSOC)) {
    $nuevoPiso = $row['piso'] + 1;
    $nuevoNumero = $row['numero'] + 1;
} else {
    // Si no hay habitaciones aún
    $nuevoPiso = 1;
    $nuevoNumero = 1;
}

// Paso 5: insertar la nueva habitación con el id disponible
$sqlInsertar = "INSERT INTO habitaciones_armenta (id, nombre, piso, numero, estado, created_at) 
                VALUES (:id, :nombre, :piso, :numero, 0, CURRENT_TIMESTAMP)";
$stmt = $dbh->prepare($sqlInsertar);

$stmt->bindParam(':id', $nuevoId);
$stmt->bindParam(':nombre', $nombre);
$stmt->bindParam(':piso', $nuevoPiso);
$stmt->bindParam(':numero', $nuevoNumero);

// Ejecutar la inserción
if ($stmt->execute()) {
    echo "<h2>✅ Habitación creada exitosamente.</h2>";
    echo "<a href='inicio.php'>Volver al inicio</a>";
} else {
    echo "<h2>❌ Error al crear la habitación.</h2>";
}

?>
