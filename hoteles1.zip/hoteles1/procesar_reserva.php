<?php

// paso1 importar el archivo de la base de datos
require 'config/conex.php';

//paso 2: capturar las variables
$habitacion= $_POST["habitacion"];

//paso 3: armar la sentencia SQL


$sql="UPDATE habitaciones_armenta
SET 
estado=1
WHERE 
id=".$habitacion."";


//paso 4: mandar la orden a la base de datos
if($dbh->query($sql )){
   //aparecera este mensaje
   echo "actualizacion correcta";
}
else{
    //error aparece esto
    echo "Error actualizando";
} 
?>