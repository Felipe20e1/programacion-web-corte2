<?php
// Incluir la conexión a la base de datos
include('conex.php');

// Consulta para obtener las habitaciones disponibles
$sql = "SELECT * FROM habitaciones_armenta WHERE estado = 0"; // Las habitaciones con estado 0 están disponibles

// Preparar la consulta
$stmt = $dbh->prepare($sql);
$stmt->execute();

// Verificar si hay habitaciones disponibles
if ($stmt->rowCount() > 0) {
    echo "<table>";
    echo "<tr><th>ID</th><th>Nombre</th><th>Piso</th><th>Número</th><th>Acción</th></tr>";

    // Mostrar las habitaciones disponibles
    while ($habitacion = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . $habitacion['id'] . "</td>";
        echo "<td>" . $habitacion['nombre'] . "</td>";
        echo "<td>" . $habitacion['piso'] . "</td>";
        echo "<td>" . $habitacion['numero'] . "</td>";
        // Aquí se hace la llamada al archivo reservar.php con el id de la habitación
        echo "<td><a href='reservar.php?id=" . $habitacion['id'] . "'>Reservar</a></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No hay habitaciones disponibles.";
}
?>
