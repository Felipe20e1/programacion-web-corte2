<?php
require 'config/conex.php';

$sql = "SELECT * FROM habitaciones_armenta ORDER BY id DESC";
$result = $dbh->query($sql);

echo "<h2>Listado de habitaciones creadas</h2>";
echo "<table border='1' cellpadding='10'>";
echo "<tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Piso</th>
        <th>Número</th>
        <th>Estado</th>
      </tr>";

while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
    $estado = $row['estado'] == 0 ? 'Disponible' : 'Reservada';
    echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['nombre']}</td>
            <td>{$row['piso']}</td>
            <td>{$row['numero']}</td>
            <td>{$estado}</td>
          </tr>";
}
echo "</table>";
?>
