<?php
include('conex.php');


$sql = "SELECT * FROM habitaciones WHERE estado = 0"; 


$stmt = $dbh->prepare($sql);
$stmt->execute();


if ($stmt->rowCount() > 0) {
    echo "<table>";
    echo "<tr><th>ID</th><th>Nombre</th><th>Piso</th><th>Número</th><th>Acción</th></tr>";

    
    while ($habitacion = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . $habitacion['id'] . "</td>";
        echo "<td>" . $habitacion['nombre'] . "</td>";
        echo "<td>" . $habitacion['piso'] . "</td>";
        echo "<td>" . $habitacion['numero'] . "</td>";
        
        echo "<td><a href='reservar.php?id=" . $habitacion['id'] . "'>Reservar</a></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No hay habitaciones disponibles.";
}
?>
