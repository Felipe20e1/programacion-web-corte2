<?php

$cantidad = $_POST["cantidad"];
$total = 1500 * $cantidad;



if($cantidad>=5){
    
    $des = $total * 0.10;
    $total = $total - $des;
    echo 'El total a pagar es'. $total;
    }else
    
    {
        
        echo 'El total a pagar es'. $total;
    }

?>