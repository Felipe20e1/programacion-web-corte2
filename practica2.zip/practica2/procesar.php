<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numero_postres = intval($_POST["numero_de_postres"]);
    $tipo_postre = $_POST["tipo_de_postre"];
    $tipo_toping = $_POST["tipo_de_toping"];
    $tipo_entrega = $_POST["tipo_de_entrega"];

    // Precios base
    $precios_postres = ["2_leches" => 6000, "3_leches" => 10000, "5_leches" => 20000];
    
    // Validar tipo de postre
    if (!isset($precios_postres[$tipo_postre])) die("Tipo de postre no válido.");

    // Calcular total
    $total_a_pagar = ($numero_postres * $precios_postres[$tipo_postre]) +
                     (($tipo_toping == 'chispas') ? 1000 * $numero_postres : 0) +
                     (($tipo_entrega == 'para_llevar') ? 2000 : 0);

    // Mostrar detalles
    echo "<h2>Resumen de la compra:</h2>
          <p><strong>Número de postres:</strong> $numero_postres</p>
          <p><strong>Tipo de postre:</strong> " . ucfirst(str_replace("_", " ", $tipo_postre)) . "</p>
          <p><strong>Topping:</strong> " . ucfirst(str_replace("_", " ", $tipo_toping)) . "</p>
          <p><strong>Tipo de entrega:</strong> " . ucfirst(str_replace("_", " ", $tipo_entrega)) . "</p>
          <h3>Total a pagar: " . number_format($total_a_pagar, 0, ',', '.') . " pesos</h3>";
}
?>
